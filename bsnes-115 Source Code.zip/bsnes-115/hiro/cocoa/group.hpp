#if defined(Hiro_Group)

namespace hiro {

struct pGroup : pObject {
  Declare(Group, Object);
};

}

#endif
