#if defined(Hiro_Group)

namespace hiro {

auto pGroup::construct() -> void {
}

auto pGroup::destruct() -> void {
}

}

#endif
