#include <sfc/slot/bsmemory/bsmemory.cpp>
#include <sfc/slot/sufamiturbo/sufamiturbo.cpp>
