auto ST0010::serialize(serializer& s) -> void {
  s.array(ram);
}
