namespace Resource {
extern const unsigned char Icon[3463];
extern const unsigned char Logo[23467];
extern const unsigned char SameBoy[32358];
namespace System {
extern const unsigned char Boards[31506];
extern const unsigned char IPLROM[64];
}
}
